const FetchRandomQuote = "https://api.quotable.io/random";
let quote = document.getElementById("showQuote") ;
let Writer = document.getElementById("authorName");
async function GetQuote(url) {
    const response = await fetch(url);
    var Data = await response.json();
    // console.log(Data);
    quote.innerHTML = Data.content;
    Writer.innerHTML = Data.author;
}
GetQuote(FetchRandomQuote);
function tweet() {
    window.open("https://twitter.com/intent/tweet?text=" + quote.innerHTML +" By-"+ Writer.innerHTML , "tweetwindow","width =700,height = 600");
}